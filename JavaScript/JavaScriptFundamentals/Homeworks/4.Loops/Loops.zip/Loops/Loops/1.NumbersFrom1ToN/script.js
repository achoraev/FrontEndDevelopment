function printNumbers() {
	var numN = jsConsole.readInteger("#numberN");
	for (var i = 0; i <= numN; i++) {
		jsConsole.writeLine(i);
	}			  
 }