function printValueOfInput() {
    var valueOfInput = document.getElementsByTagName('input')[0];    
    alert("You enter this: " + valueOfInput.value);
}